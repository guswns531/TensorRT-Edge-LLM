
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} rmsnorm_fp16_h5120_wbc1__arch110_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_rmsnorm_fp16_h5120_wbc1__arch110_cuda_init(void **);
void _mlir_rmsnorm_fp16_h5120_wbc1__arch110_cuda_load_to_device(void **);
static inline void rmsnorm_fp16_h5120_wbc1__arch110_Kernel_Module_Load(rmsnorm_fp16_h5120_wbc1__arch110_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_rmsnorm_fp16_h5120_wbc1__arch110_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_rmsnorm_fp16_h5120_wbc1__arch110_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void rmsnorm_fp16_h5120_wbc1__arch110_Kernel_Module_Unload(rmsnorm_fp16_h5120_wbc1__arch110_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} rmsnorm_fp16_h5120_wbc1__arch110_Tensor_x_t;


typedef struct {
    void *data;
} rmsnorm_fp16_h5120_wbc1__arch110_Tensor_gamma_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} rmsnorm_fp16_h5120_wbc1__arch110_Tensor_output_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_rmsnorm_fp16_h5120_wbc1__arch110__mlir_ciface_cutlass_aot_adapter_FakeTensorFloat16div1512051201_FakeTensorFloat1651201_FakeTensorFloat16div1512051201___CUstream0x0(void **args, int32_t num_args);

static inline int32_t cute_dsl_rmsnorm_fp16_h5120_wbc1__arch110_wrapper(rmsnorm_fp16_h5120_wbc1__arch110_Kernel_Module_t *module, rmsnorm_fp16_h5120_wbc1__arch110_Tensor_x_t *x, rmsnorm_fp16_h5120_wbc1__arch110_Tensor_gamma_t *gamma, rmsnorm_fp16_h5120_wbc1__arch110_Tensor_output_t *output, int64_t rows, float eps, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[7] = {
        x, gamma, output, &rows, &eps, &stream,
        &ret
    };
    _mlir_rmsnorm_fp16_h5120_wbc1__arch110__mlir_ciface_cutlass_aot_adapter_FakeTensorFloat16div1512051201_FakeTensorFloat1651201_FakeTensorFloat16div1512051201___CUstream0x0(args, 7);
    return ret;
}
