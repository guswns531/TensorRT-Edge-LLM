
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} qsa_sparse_decode_d256_bf16_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_qsa_sparse_decode_d256_bf16_cuda_init(void **);
void _mlir_qsa_sparse_decode_d256_bf16_cuda_load_to_device(void **);
static inline void qsa_sparse_decode_d256_bf16_Kernel_Module_Load(qsa_sparse_decode_d256_bf16_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_qsa_sparse_decode_d256_bf16_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_qsa_sparse_decode_d256_bf16_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void qsa_sparse_decode_d256_bf16_Kernel_Module_Unload(qsa_sparse_decode_d256_bf16_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} qsa_sparse_decode_d256_bf16_Tensor_q_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} qsa_sparse_decode_d256_bf16_Tensor_kv_pool_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} qsa_sparse_decode_d256_bf16_Tensor_page_table_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} qsa_sparse_decode_d256_bf16_Tensor_indices_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} qsa_sparse_decode_d256_bf16_Tensor_context_lengths_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} qsa_sparse_decode_d256_bf16_Tensor_o_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} qsa_sparse_decode_d256_bf16_Tensor_partial_o_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} qsa_sparse_decode_d256_bf16_Tensor_partial_stats_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} qsa_sparse_decode_d256_bf16_Tensor_counters_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_qsa_sparse_decode_d256_bf16__mlir_ciface_cutlass___call_____main__QSASparseGQADecode_object_at__FakeTensorBFloat16div1div1div1256i64div256i64div2562561_FakeTensorBFloat16div1div1div1div1i64div1i64div1i64div11_FakeTensorIn(void **args, int32_t num_args);

static inline int32_t cute_dsl_qsa_sparse_decode_d256_bf16_wrapper(qsa_sparse_decode_d256_bf16_Kernel_Module_t *module, qsa_sparse_decode_d256_bf16_Tensor_q_tensor_t *q_tensor, qsa_sparse_decode_d256_bf16_Tensor_kv_pool_t *kv_pool, qsa_sparse_decode_d256_bf16_Tensor_page_table_t *page_table, qsa_sparse_decode_d256_bf16_Tensor_indices_t *indices, qsa_sparse_decode_d256_bf16_Tensor_context_lengths_t *context_lengths, qsa_sparse_decode_d256_bf16_Tensor_o_tensor_t *o_tensor, qsa_sparse_decode_d256_bf16_Tensor_partial_o_t *partial_o, qsa_sparse_decode_d256_bf16_Tensor_partial_stats_t *partial_stats, qsa_sparse_decode_d256_bf16_Tensor_counters_t *counters, float attention_scale, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[12] = {
        q_tensor, kv_pool, page_table, indices, context_lengths, o_tensor, partial_o, partial_stats, counters, &attention_scale, &stream,
        &ret
    };
    _mlir_qsa_sparse_decode_d256_bf16__mlir_ciface_cutlass___call_____main__QSASparseGQADecode_object_at__FakeTensorBFloat16div1div1div1256i64div256i64div2562561_FakeTensorBFloat16div1div1div1div1i64div1i64div1i64div11_FakeTensorIn(args, 12);
    return ret;
}
